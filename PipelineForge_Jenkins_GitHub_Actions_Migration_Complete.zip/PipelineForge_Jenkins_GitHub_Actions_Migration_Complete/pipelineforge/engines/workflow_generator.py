from pathlib import Path

def workflow_for(item):
    steps=["      - uses: actions/checkout@v4"]
    if item.get('maven'): steps += ["      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: '17'", "      - run: mvn -B test package"]
    elif item.get('gradle'): steps += ["      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: '17'", "      - run: ./gradlew build"]
    elif item.get('node'): steps += ["      - uses: actions/setup-node@v4\n        with:\n          node-version: '20'", "      - run: npm ci", "      - run: npm test"]
    elif item.get('python'): steps += ["      - uses: actions/setup-python@v5\n        with:\n          python-version: '3.12'", "      - run: pip install -r requirements.txt", "      - run: pytest -q"]
    elif item.get('dotnet'): steps += ["      - uses: actions/setup-dotnet@v4\n        with:\n          dotnet-version: '8.0.x'", "      - run: dotnet build", "      - run: dotnet test --no-build"]
    else: steps += ["      - run: echo 'TODO: replace with project-specific build and test steps'"]
    return "name: Migrated CI\non:\n  push:\n  pull_request:\npermissions:\n  contents: read\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n"+'\n'.join(steps)+'\n'

def generate(items,outdir):
    out=Path(outdir); out.mkdir(parents=True,exist_ok=True); files=[]
    for i,x in enumerate(items,1):
        name=(x.get('jenkins_job') or x.get('full_name') or f'job-{i}').replace('/','__').replace(' ','_')+'.yml'
        (out/name).write_text(workflow_for(x),encoding='utf-8'); files.append(str(out/name))
    return files
