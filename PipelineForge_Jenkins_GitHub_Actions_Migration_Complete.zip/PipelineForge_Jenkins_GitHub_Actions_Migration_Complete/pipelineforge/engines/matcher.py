def match(item):
    if item.get('maven'): return {'template':'java-maven.yml','confidence':0.90}
    if item.get('gradle'): return {'template':'java-gradle.yml','confidence':0.90}
    if item.get('node'): return {'template':'node.yml','confidence':0.88}
    if item.get('python'): return {'template':'python.yml','confidence':0.88}
    if item.get('dotnet'): return {'template':'dotnet.yml','confidence':0.88}
    return {'template':'generic.yml','confidence':0.60}
