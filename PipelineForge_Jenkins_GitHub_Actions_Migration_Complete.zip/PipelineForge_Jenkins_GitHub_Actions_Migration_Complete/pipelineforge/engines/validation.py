def validate(items):
    checks=[]
    for x in items:
        checks.append({'job':x.get('jenkins_job') or x.get('full_name'),'source_mapped':bool(x.get('scm_detected') or x.get('scm_url')),'workflow_generated':bool(x.get('workflow_file')),'risk_count':len(x.get('risks',[]))})
    return checks
