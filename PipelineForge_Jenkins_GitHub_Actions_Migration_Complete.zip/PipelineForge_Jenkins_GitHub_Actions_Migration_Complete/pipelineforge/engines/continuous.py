def diff(old,new,key='full_name'):
    a={x.get(key):x for x in old}; b={x.get(key):x for x in new}
    return {'added':[b[k] for k in b.keys()-a.keys()],'removed':[a[k] for k in a.keys()-b.keys()],'changed':[{'before':a[k],'after':b[k]} for k in a.keys()&b.keys() if a[k]!=b[k]]}
