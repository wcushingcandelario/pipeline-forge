import os, requests
from urllib.parse import urljoin

class JenkinsClient:
    def __init__(self, base_url=None, username=None, token=None, verify_ssl=None, timeout=30):
        self.base_url=(base_url or os.getenv('JENKINS_URL','')).rstrip('/')+'/'
        self.username=username or os.getenv('JENKINS_USER')
        self.token=token or os.getenv('JENKINS_TOKEN')
        env_verify=os.getenv('JENKINS_VERIFY_SSL','true').lower()=='true'
        self.verify_ssl=env_verify if verify_ssl is None else verify_ssl
        self.timeout=timeout
        self.session=requests.Session()
        if self.username and self.token:
            self.session.auth=(self.username,self.token)
    def _get(self,url,**kwargs):
        r=self.session.get(url,verify=self.verify_ssl,timeout=self.timeout,**kwargs); r.raise_for_status(); return r
    def api_json(self, url=None, tree=None):
        target=url or self.base_url
        api=urljoin(target.rstrip('/')+'/', 'api/json')
        params={'tree':tree} if tree else None
        return self._get(api,params=params).json()
    def config_xml(self, job_url):
        return self._get(urljoin(job_url.rstrip('/')+'/', 'config.xml')).text
    def test(self):
        d=self.api_json(tree='mode,nodeDescription,numExecutors'); return {'ok':True,'mode':d.get('mode'),'executors':d.get('numExecutors')}
