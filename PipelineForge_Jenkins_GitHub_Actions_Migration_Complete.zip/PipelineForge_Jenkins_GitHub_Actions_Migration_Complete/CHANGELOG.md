# Changelog

## 1.0.0 — Complete consolidated edition
- Merged recovered Phase 8 architecture and later engine/service updates.
- Added corrected Jenkins client, discovery, config intelligence, analysis, patterns, matcher, planner, workflow generation, reports, demo, tests, and cross-platform setup.
- Preserved later recovered Module 4 and Jira generator under `legacy_recovered/`.
