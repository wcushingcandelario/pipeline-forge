# WORK COMMAND CENTER — FOLDER MAP

00 Inbox — capture first
01 Daily — daily control
02 Meetings — meeting notes
03 Projects — active projects
04 People — people / 1-on-1s
05 Decisions — decisions
06 Reference — reference material
07 Tasks — normal tasks
08 Waiting For — waiting items
09 Follow Up — follow-up items
10 I Owe — commitments made by you
11 Calls — calls
90 Templates — reusable templates
99 Archive — completed / inactive material

COMMAND CENTER.md — main home page
