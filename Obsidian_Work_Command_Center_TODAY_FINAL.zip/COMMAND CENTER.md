---
cssclasses:
  - proactive-dashboard
---

# WORK COMMAND CENTER

> [!info] 🔵 ORGANIZATIONAL COACH
> **Open here. Follow the coach. Capture what changes. Close the loop.**

**Capture • Organize • Execute • Review**

## 🔵 TODAY'S CONTROL

```dataview
LIST
FROM "01 Daily"
WHERE file.name = dateformat(date(today), "cccc, MMMM D, YYYY")
```

> [!tip] Daily rhythm
> **Start-of-Day Control → Midday Check-In → Afternoon Follow-Up → Shutdown**

# 🔴 NEEDS ATTENTION

## Overdue

```tasks
not done
due before today
sort by due
```

## Waiting For — Overdue

```tasks
not done
tags include #waiting
due before today
sort by due
```

## Follow-Up — Overdue

```tasks
not done
tags include #followup
due before today
sort by due
```

## I Owe — Overdue

```tasks
not done
tags include #iowe
due before today
sort by due
```

## Calls — Overdue

```tasks
not done
tags include #call
due before today
sort by due
```

# 🟠 TODAY

## Due Today

```tasks
not done
due today
tags do not include #waiting
tags do not include #iowe
tags do not include #followup
tags do not include #call
sort by priority
```

## Calls Today

```tasks
not done
tags include #call
due today
sort by due
```

## Follow-Ups Today

```tasks
not done
tags include #followup
due today
sort by due
```

## I Owe Today

```tasks
not done
tags include #iowe
due today
sort by due
```

## Expected Today

```tasks
not done
tags include #waiting
due today
sort by due
```

# 🟠 DUE SOON — PREPARE NOW

```tasks
not done
due after today
due before in 4 days
tags do not include #waiting
sort by due
```

# 🟡 UPCOMING

```tasks
not done
due after today
due before in 8 days
sort by due
```

# 🟣 MEETING ACTIONS

```tasks
not done
path includes "02 Meetings"
sort by due
```

# 🔵 PROJECT PULSE

```dataview
TABLE status AS "Status", owner AS "Owner", next_action AS "Next Action", due AS "Due"
FROM "03 Projects"
WHERE type = "project" AND status != "complete"
SORT due ASC
```

## Projects Going Quiet

```dataview
TABLE owner AS "Owner", file.mtime AS "Last Updated", next_action AS "Next Action"
FROM "03 Projects"
WHERE type = "project"
AND status != "complete"
AND file.mtime <= date(today) - dur(7 days)
SORT file.mtime ASC
```

# 🟠 COACHING WATCHLIST

## Inbox Sitting Too Long

```dataview
LIST
FROM "00 Inbox"
WHERE file.mtime <= date(today) - dur(3 days)
SORT file.mtime ASC
```

> [!warning] Coach
> **If something has been sitting unprocessed, decide: Do · Schedule · Delegate · Track · Delete.**

# ➕ QUICK CAPTURE

**Task · Call · Follow-Up · Waiting For · I Owe · Meeting · Project · Inbox**

> [!success] System rule
> **Capture once. The Command Center does the surfacing.**
