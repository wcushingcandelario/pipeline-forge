---
type: project
status: active
owner:
next_action: Test the Command Center
due:
---

# Example Project

## Purpose / Outcome

Verify the project roll-up.

## Current Status

Testing.

## Next Action

- [ ] Test the Command Center

## Latest Update

2026-08-16 — Initial test project.
