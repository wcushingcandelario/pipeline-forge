# WORK COMMAND CENTER — TODAY FINAL

This package is the complete from-scratch Windows Work Command Center incorporating the items covered and modified today.

## INCLUDED FOLDERS

00 Inbox
01 Daily
02 Meetings
03 Projects
04 People
05 Decisions
06 Reference
07 Tasks
08 Waiting For
09 Follow Up
10 I Owe
11 Calls
90 Templates
99 Archive

## INCLUDED

- Full Command Center dashboard
- Daily Control workflow
- Weekly Review
- Meeting template we finalized today
- Native Meeting actions that work in Reading View
- Task
- Waiting For
- Follow Up
- I Owe
- Call
- Project
- Inbox
- People / 1-on-1
- Decision Record
- Things 3-inspired light styling
- #007AFF accent
- Obsidian settings
- Daily Notes settings
- Templates settings
- Dataview configuration
- Tasks configuration
- Community plugin list
- Quick Capture menu
- Example Meeting / Project / Daily notes
- Setup instructions

## START FROM SCRATCH

1. Unzip this package.
2. Open Obsidian.
3. Select **Open folder as vault**.
4. Select the unzipped `Obsidian_Work_Command_Center_TODAY_FINAL` folder.
5. Open `COMMAND CENTER.md`.

## COMMUNITY PLUGINS

Install and enable:

- Dataview
- Tasks
- QuickAdd

The configuration files are already present. Obsidian still requires the plugin binaries to be installed through Community Plugins.

## TEMPLATES

The template folder is:

`90 Templates`

Daily Notes:
- Folder: `01 Daily`
- Template: `90 Templates/Daily Control.md`

## MEETING SYSTEM

Use:

`90 Templates/Meeting.md`

The Actions section is:

- [ ] Action

You can check it directly in Reading View.

There is intentionally NO separate "Meeting Action" type. This was changed today to keep the system clean.

## QUICK CAPTURE TYPES

- Task
- Call
- Follow-Up
- Waiting For
- I Owe
- Meeting
- Project
- Inbox

These map to the dedicated folders included in this package.

## FIRST TEST

1. Open `COMMAND CENTER.md`.
2. Open `02 Meetings/Example Meeting.md`.
3. Confirm the checkbox works in Reading View.
4. Open `COMMAND CENTER.md`.
5. Confirm the meeting action is surfaced after Tasks is installed.
6. Delete the example notes after testing.

This is intended to be the clean starting point after the old vault was deleted.
