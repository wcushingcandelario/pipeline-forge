---
type: call
date: {{date:YYYY-MM-DD}}
person:
tags:
  - call
---

# Call — {{date:YYYY-MM-DD}}

**Person:**  

## Notes

- 

## Actions

- [ ] 
