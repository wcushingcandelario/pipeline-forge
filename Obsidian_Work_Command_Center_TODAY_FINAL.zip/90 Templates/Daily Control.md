---
type: daily
date: {{date:YYYY-MM-DD}}
---

# Daily Control — {{date:dddd, MMMM D, YYYY}}

> **Start-of-Day Control → Midday Check-In → Afternoon Follow-Up → Shutdown**

## ☀️ START-OF-DAY CONTROL

- [ ] Review calendar
- [ ] Review Inbox
- [ ] Review overdue items
- [ ] Review Waiting For
- [ ] Review Follow-Ups
- [ ] Review I Owe
- [ ] Prepare for today's meetings
- [ ] Identify today's Top 3

## 🎯 TODAY'S TOP 3

- [ ] #top3
- [ ] #top3
- [ ] #top3

## 📅 TODAY'S MEETINGS

- 

## 📝 NOTES / CAPTURE

- 

## 🔄 MIDDAY CHECK-IN

- [ ] Review progress
- [ ] Re-plan anything slipping
- [ ] Capture new commitments

## 📤 AFTERNOON FOLLOW-UP

- [ ] Send required follow-ups
- [ ] Check Waiting For
- [ ] Check I Owe
- [ ] Check Calls

## 🌙 SHUTDOWN

- [ ] Process Inbox
- [ ] Process notes
- [ ] Update tasks
- [ ] Update Waiting / Follow-Up
- [ ] Check tomorrow's calendar
- [ ] Set tomorrow's Top 3

**Wins:**  

**Carry Forward:**  

**Tomorrow's First Action:**  
