---
type: follow-up
date: {{date:YYYY-MM-DD}}
follow_up_date:
person:
tags:
  - followup
---

# Follow-Up

**Person:**  
**Follow-Up Date:**  

## Notes

- 
