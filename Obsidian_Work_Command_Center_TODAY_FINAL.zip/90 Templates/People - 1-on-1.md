---
type: person
person:
role:
---

# 1-on-1

**Person:**  
**Role:**  

## Context

## Discussion

- 

## Their Priorities

- 

## My Commitments

- [ ] 

## Their Commitments

- 

## Follow-Up

- 

## Decisions

- 

## Concerns / Blockers

- 

## Next 1-on-1

- 
