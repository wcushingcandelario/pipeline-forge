---
type: inbox
date: {{date:YYYY-MM-DD}}
---

# Inbox — {{date:YYYY-MM-DD}}

## Capture

- 
