---
type: waiting
status: waiting
date: {{date:YYYY-MM-DD}}
due:
person:
tags:
  - waiting
---

# Waiting For

**Person:**  
**Expected:**  

## Notes

- 
