# Quick Capture Menu

Use these eight capture types:

1. Task → `07 Tasks`
2. Call → `11 Calls`
3. Follow-Up → `09 Follow Up`
4. Waiting For → `08 Waiting For`
5. I Owe → `10 I Owe`
6. Meeting → `02 Meetings`
7. Project → `03 Projects`
8. Inbox → `00 Inbox`

**Important:** Meeting actions are ordinary native checkbox Tasks. There is no separate Meeting Action type.
