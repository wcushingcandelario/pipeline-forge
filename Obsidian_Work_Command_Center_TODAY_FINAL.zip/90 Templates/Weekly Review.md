---
type: weekly-review
week: {{date:YYYY-[W]WW}}
---

# Weekly Review — {{date:YYYY-[W]WW}}

## 1. INBOX / CAPTURE

- [ ] Process Inbox
- [ ] Process loose notes
- [ ] Capture anything still in my head

## 2. PROJECT REVIEW

- [ ] Review every active project
- [ ] Update status and next milestone
- [ ] Confirm next action and owner
- [ ] Identify risks / blockers
- [ ] Check projects going quiet

## 3. COMMITMENTS

- [ ] Review commitments I made
- [ ] Review commitments others made to me

## 4. WAITING / FOLLOW-UP

- [ ] Review Waiting For
- [ ] Send overdue follow-ups
- [ ] Schedule future follow-ups

## 5. CALENDAR / LOOK AHEAD

- [ ] Review next 14 days
- [ ] Prepare for important meetings
- [ ] Identify deadlines and decision points

## 6. PEOPLE

- [ ] Review important 1-on-1 / people notes
- [ ] Capture coaching / recognition / follow-up needs

## 7. NEXT WEEK

- [ ] Define Top 3 outcomes
- [ ] 
- [ ] 
