---
type: meeting
date: {{date:YYYY-MM-DD}}
project:
---

# Meeting — {{date:YYYY-MM-DD}}

**Project:**  
**People:**  
**Purpose:**  

## Notes

- 

## Decisions

- 

## Actions

- [ ] 

## Follow-Up

- 

## Next Meeting

**Date:**  
**Topic:**  
