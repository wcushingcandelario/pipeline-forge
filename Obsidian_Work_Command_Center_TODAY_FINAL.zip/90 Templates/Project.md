---
type: project
status: active
owner:
next_action:
due:
---

# Project

## Purpose / Outcome

## Current Status

## Next Action

- [ ] 

## Next Milestone

**Milestone:**  
**Due:**  

## Waiting

## Risks / Blockers

## Decisions

## Key People

## Important Links / Files

## Latest Update

**Date:**  
**What changed:**  
**What happens next:**  

## Status Check

- [ ] Current status is clear
- [ ] Next action is clear
- [ ] Owner is clear
- [ ] Due date is clear
- [ ] Blockers are clear
