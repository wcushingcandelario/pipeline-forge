---
type: decision
date: {{date:YYYY-MM-DD}}
project:
owner:
---

# Decision — {{date:YYYY-MM-DD}}

**Project / Area:**  
**Owner:**  

## Context

## Options Considered

- 

## Decision

## Why

## Impact / Consequences

## Follow-Up

- [ ] 
